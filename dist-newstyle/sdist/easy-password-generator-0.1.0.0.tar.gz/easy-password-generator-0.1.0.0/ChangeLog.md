# Changelog for easy-password-generator
## 0.1.0.0
- First real versioning of the project

## Unreleased changes
- None
